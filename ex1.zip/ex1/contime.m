x0=[-0.28;0.36;0.1;0.27;0.54;-0.09;0.18;-0.36;-0.54;-0.18];
[t,x]=ode45('f2',[0 3],x0);x11=x(:,1);x12=x(:,2);x21=x(:,3);x22=x(:,4);x31=x(:,5);x32=x(:,6);x41=x(:,7);x42=x(:,8);x51=x(:,9);x52=x(:,10);plot(x11,x12,'-R',x21,x22,'-b',x31,x32,'-G',x41,x42,'-M',x51,x52,'-c','linewidth',1);hold on;plot

(0,0,'ko','markersize',5);plot(t,x11,'-R',t,x21,'-b',t,x31,'-G',t,x41,'-M',t,x51,'-c','linewidth',1);legend('agent 1','agent 2','agent 3','agent 4','agent 5');
xlabel('time t');plot(t,x12,'-R',t,x22,'-b',t,x32,'-G',t,x42,'-M',t,x52,'-c','linewidth',1);legend('agent 1','agent 2','agent 3','agent 4','agent 5');
xlabel('time t');ylabel('state x_{i2}');



