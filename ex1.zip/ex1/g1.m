function y=g1(x)
y=(x+10)^(-1);







