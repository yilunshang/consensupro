function y=g(x)
y=exp(-x);






