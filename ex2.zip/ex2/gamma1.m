function y=gamma1(x)
if x>=0 & x<2
y=x;else
y=2;end








