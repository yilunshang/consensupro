function y=g(x)
if x<2
y=1;else
y=0;end




